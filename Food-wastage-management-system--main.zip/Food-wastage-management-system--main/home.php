<?php
include 'db.php';
include 'header.php';
?>
<html>
<head>
<link href="style.css" rel="stylesheet">
</head>
<body id="slider_container_1"  style="margin-left: 18%; margin-right:15%">
<div id="home">

<div id="slogan1">
</div>
<div id="slogantext">
<div id="homehead">
Avoid Food Wastage
</div>
 Food loss occurs when food is thrown out or somehow decreases in quality during processing (i.e., before it hits supermarket shelves); it’s mostly an issue in so-called developing countries. Food waste, on the other hand,
 tends to be a major issue in “developed” countries such as the U.S.It refers to situations when food makes it to the end of the food supply chain but still doesn’t get consumed. Currently, one third of food produced for human consumption is lost or wasted globally. That’s about 1.3 billion tons of nom-worthy edibles per year, and less than a quarter of it could feed hungry people the world over.
</div>
<div id="slogan2">
</div>
</div>
</body>
</html>